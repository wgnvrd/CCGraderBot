import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class First implements FirstI {
    String fileN;

    public First(String object) {
        fileN = object;
    }

    @Override
    public void fillArray(int start, boolean ascend, int[] values) {
        
        int mult = -1;
        if(ascend){
            mult = 1;
        }
        values[0] = start;
        for(int i = 0; i < values.length; i++){
            
            values[i] = start+i*mult;
        }
    }

    @Override
    public void setFilename(String filename) {
        fileN = filename;
   
    }

    @Override
    public String getFilename() {
        return fileN;
        // TODO Auto-generated method stub
 
    }

    @Override
    public int seekLetter(char l) throws FirstException, IOException {
        if(fileN == null){
            throw new FirstException();
        }
        int count = 0;
        System.out.println(new File(".").getAbsolutePath());
        File file = new File(fileN);
        FileReader read = new FileReader(file);
        int i;
        while ((i = read.read()) != -1) {
            if((char)i == l){
                count += 1;
            }
        }
        read.close();
        return count;
        
    }
    
}
