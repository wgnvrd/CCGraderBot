/** Exception to indicate that the filename has not been set */
public class FirstException extends Exception {

}